package CognizantDN;

import java.util.Arrays;
import java.util.Comparator;

public class SearchAlgorithms {
	public static Product1 linearSearch(Product1[] products, String productName) {
        for (Product1 product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search
    public static Product1 binarySearch(Product1[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(productName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product1[] products = {
            new Product1("101", "Laptop", "Electronics"),
            new Product1("102", "Smartphone", "Electronics"),
            new Product1("103", "Book", "Literature"),
            new Product1("104", "Pen", "Stationery"),
            new Product1("105", "Desk", "Furniture")
        };

        // Linear Search
        Product1 foundProduct = linearSearch(products, "Laptop");
        System.out.println("Linear Search Result: " + (foundProduct != null ? foundProduct : "Product not found"));

        // Binary Search
        Arrays.sort(products);
        foundProduct = binarySearch(products, "Laptop");
        System.out.println("Binary Search Result: " + (foundProduct != null ? foundProduct : "Product not found"));
    }
}
