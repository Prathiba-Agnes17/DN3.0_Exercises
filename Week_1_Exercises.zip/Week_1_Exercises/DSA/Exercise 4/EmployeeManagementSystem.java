
package CognizantDN;

import java.util.Arrays;

public class EmployeeManagementSystem {
	private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size == capacity) {
            // If the array is full, double its capacity
            capacity *= 2;
            employees = Arrays.copyOf(employees, capacity);
        }
        employees[size++] = employee;
    }

    // Search for an employee by employeeId
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse the array and print all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by employeeId
    public void deleteEmployee(String employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[--size] = null;
        }
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);
        
        // Add employees
        ems.addEmployee(new Employee("E101", "Alice", "Manager", 60000));
        ems.addEmployee(new Employee("E102", "Bob", "Developer", 50000));
        ems.addEmployee(new Employee("E103", "Charlie", "Designer", 45000));
        ems.addEmployee(new Employee("E104", "David", "Developer", 50000));
        ems.addEmployee(new Employee("E105", "Eve", "HR", 55000));
        
        // Traverse and print all employees
        System.out.println("All Employees:");
        ems.traverseEmployees();
        
        // Search for an employee
        System.out.println("\nSearching for Employee with ID E103:");
        Employee emp = ems.searchEmployee("E103");
        System.out.println(emp != null ? emp : "Employee not found");

        // Delete an employee
        System.out.println("\nDeleting Employee with ID E104:");
        ems.deleteEmployee("E104");
        ems.traverseEmployees();
    }

}
