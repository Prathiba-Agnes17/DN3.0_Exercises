package CognizantDN;

import java.util.List;

public class Library {
	  public static Book linearSearchByTitle(List<Book> books, String title) {
	        for (Book book : books) {
	            if (book.title.equalsIgnoreCase(title)) {
	                return book;
	            }
	        }
	        return null;
	    }
	  public static Book binarySearchByTitle(List<Book> books, String title) {
	        int left = 0;
	        int right = books.size() - 1;

	        while (left <= right) {
	            int middle = left + (right - left) / 2;
	            Book middleBook = books.get(middle);
	            int comparison = middleBook.title.compareToIgnoreCase(title);

	            if (comparison == 0) {
	                return middleBook;
	            } else if (comparison < 0) {
	                left = middle + 1;
	            } else {
	                right = middle - 1;
	            }
	        }
	        return null;
	    }

}
