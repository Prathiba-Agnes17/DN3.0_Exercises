package CognizantDN;

public class Main {
	public static void main(String[] args) {
        // Create a model
        Student model = new Student("John Doe", 1, "A");

        // Create a view
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(model, view);

        // Update view with the initial student details
        controller.updateView();

        // Update the model's details
        controller.setStudentName("Jane Doe");
        controller.setStudentId(2);
        controller.setStudentGrade("B");

        // Update view with the updated student details
        controller.updateView();
    }

}
