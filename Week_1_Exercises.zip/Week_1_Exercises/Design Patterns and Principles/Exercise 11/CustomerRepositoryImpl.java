package CognizantDN;

public class CustomerRepositoryImpl implements CustomerRepository {
	 @Override
	    public Customer findCustomerById(int id) {
	        // Simulate database operation
	        return new Customer(id, "John Doe");
	    }

}
