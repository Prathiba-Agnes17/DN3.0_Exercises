package CognizantDN;
import CognizantDN.CustomerRepository;
import CognizantDN.CustomerRepositoryImpl;
import CognizantDN.CustomerService;
import CognizantDN.Customer;

public class MainDriver {
	 public static void main(String[] args) {
	        // Create an instance of CustomerRepository
	        CustomerRepository customerRepository = new CustomerRepositoryImpl();

	        // Inject CustomerRepository into CustomerService
	        CustomerService customerService = new CustomerService(customerRepository);

	        // Use CustomerService to find a customer
	        Customer customer = customerService.getCustomer(1);

	        // Display the customer details
	        System.out.println("Customer ID: " + customer.getId());
	        System.out.println("Customer Name: " + customer.getName());
	    }

}
