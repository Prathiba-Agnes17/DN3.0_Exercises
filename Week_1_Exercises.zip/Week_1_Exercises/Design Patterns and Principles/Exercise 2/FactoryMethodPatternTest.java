package CognizantDN;

public class FactoryMethodPatternTest {
	public static void main(String[] args) {
        // Create factories for each document type
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        // Create and use Word document
        Document wordDocument = wordFactory.createDocument();
        wordDocument.open();
        wordDocument.save();

        // Create and use PDF document
        Document pdfDocument = pdfFactory.createDocument();
        pdfDocument.open();
        pdfDocument.save();

        // Create and use Excel document
        Document excelDocument = excelFactory.createDocument();
        excelDocument.open();
        excelDocument.save();
    }

}
