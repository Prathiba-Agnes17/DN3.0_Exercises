package CognizantDN;

public class BuilderPatternTest {
	 public static void main(String[] args) {
	        // Creating a basic computer
	        Computer basicComputer = new Computer.Builder()
	                .setCPU("Intel i3")
	                .setRAM("8GB")
	                .setStorage("256GB SSD")
	                .build();

	        System.out.println("Basic Computer Configuration:");
	        System.out.println("CPU: " + basicComputer.getCPU());
	        System.out.println("RAM: " + basicComputer.getRAM());
	        System.out.println("Storage: " + basicComputer.getStorage());

	        // Creating a gaming computer
	        Computer gamingComputer = new Computer.Builder()
	                .setCPU("Intel i9")
	                .setRAM("32GB")
	                .setStorage("1TB SSD")
	                .setGraphicsCard("NVIDIA RTX 3080")
	                .setPowerSupply("750W")
	                .setMotherboard("Asus ROG")
	                .build();

	        System.out.println("\nGaming Computer Configuration:");
	        System.out.println("CPU: " + gamingComputer.getCPU());
	        System.out.println("RAM: " + gamingComputer.getRAM());
	        System.out.println("Storage: " + gamingComputer.getStorage());
	        System.out.println("Graphics Card: " + gamingComputer.getGraphicsCard());
	        System.out.println("Power Supply: " + gamingComputer.getPowerSupply());
	        System.out.println("Motherboard: " + gamingComputer.getMotherboard());
	    }

}
