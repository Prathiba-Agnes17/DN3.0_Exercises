package CognizantDN;

public class AdapterPatternExample {
	public static void main(String[] args) {
		 PaymentProcessor paypalProcessor = new PayPalAdapter(new PayPal());
	        PaymentProcessor stripeProcessor = new StripeAdapter(new Stripe());

	        paypalProcessor.processPayment(100.0);
	        stripeProcessor.processPayment(200.0);
	    }
	}
