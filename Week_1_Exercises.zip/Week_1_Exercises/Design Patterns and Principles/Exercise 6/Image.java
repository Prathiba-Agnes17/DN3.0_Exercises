package CognizantDN;

public interface Image {
	void display();

}
