package CognizantDN;

public interface Observer {
	void update(double price);

}
