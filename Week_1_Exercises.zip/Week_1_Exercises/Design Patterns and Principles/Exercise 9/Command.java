package CognizantDN;

public interface Command {
	 void execute();

}
