//Inventory Management System
package CognizantDN;
import java.util.HashMap;
import java.util.Map;

public class InventoryManagement {
	private Map<String, Product> inventory;

    public InventoryManagement() {
        this.inventory = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    // Method to update a product
    public void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }

    // Method to display the inventory
    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement();
        
        // Adding products
        inventory.addProduct(new Product("101", "Laptop", 10, 999.99));
        inventory.addProduct(new Product("102", "Smartphone", 20, 499.99));
        
        // Display inventory
        inventory.displayInventory();
        
        // Update a product
        inventory.updateProduct(new Product("101", "Laptop", 15, 999.99));
        
        // Delete a product
        inventory.deleteProduct("102");
        
        // Display inventory
        inventory.displayInventory();
    }
}

