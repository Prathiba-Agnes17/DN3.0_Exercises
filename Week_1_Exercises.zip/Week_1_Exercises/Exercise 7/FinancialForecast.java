package CognizantDN;

public class FinancialForecast {
	// Recursive method to calculate future value
    public static double calculateFutureValue(double PV, double r, int n) {
        // Base case: if n is 0, the future value is the present value
        if (n == 0) {
            return PV;
        }
        // Recursive case: calculate future value for (n-1) periods and apply growth rate
        return calculateFutureValue(PV, r, n - 1) * (1 + r);
    }

    public static void main(String[] args) {
        double presentValue = 1000;  // Initial amount
        double growthRate = 0.05;    // Growth rate per period (5%)
        int periods = 10;            // Number of periods

        double futureValue = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods: " + futureValue);
    }
    

}
