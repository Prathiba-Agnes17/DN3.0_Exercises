package CognizantDN;
import java.util.HashMap;
import java.util.Map;

public class Financialforecast_ {
	// Memoization map to store previously computed results
    private static Map<Integer, Double> memo = new HashMap<>();

    // Recursive method with memoization to calculate future value
    public static double calculateFutureValue(double PV, double r, int n) {
        // Base case: if n is 0, the future value is the present value
        if (n == 0) {
            return PV;
        }
        // Check if result is already computed
        if (memo.containsKey(n)) {
            return memo.get(n);
        }
        // Recursive case: calculate future value for (n-1) periods and apply growth rate
        double futureValue = calculateFutureValue(PV, r, n - 1) * (1 + r);
        // Store the result in the memoization map
        memo.put(n, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000;  // Initial amount
        double growthRate = 0.05;    // Growth rate per period (5%)
        int periods = 10;            // Number of periods

        double futureValue = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value after " + periods + " periods: " + futureValue);
    }
	

}
